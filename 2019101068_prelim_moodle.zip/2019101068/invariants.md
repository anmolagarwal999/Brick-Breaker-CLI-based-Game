* Center of paddle can never be at the edge and hence, ball placement at center is always valid
* Contact with Explosive Brick destroys BRICK, not just reduces strength by one level
* forced is True only if in breaking due to being in contact with an ExplosiveBrick OR ThruBall case
*
*
*
*
*
*
*
*
*
*
*
*
