from game import Game
#print('\033[2J') # clear screen
print("\033[2J\033[1;1H") # clear screen
print("---------------------------------------------------")
game_obj = Game()
game_obj.start_game()