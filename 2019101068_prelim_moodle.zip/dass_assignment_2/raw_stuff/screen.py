import os
import numpy as np
from colorama import init as cinit
from colorama import Fore, Back, Style
import random
import time

import config as conf
import utils

###############################################################
import logging


def namestr(obj, namespace):
    return [name for name in namespace if namespace[name] is obj]


def debug_print(var_name):

    calling_frame = sys._getframe().f_back
    var_val = calling_frame.f_locals.get(
        var_name, calling_frame.f_globals.get(var_name, None))
    logging.debug(var_name + ':' + str(var_val))


def part():
    logging.debug("----------------------------------------")
# DEBUG: Detailed information, typically of interest only when diagnosing problems.

# INFO: Confirmation that things are working as expected.

# WARNING: An indication that something unexpected happened, or indicative of some problem in the near future (e.g. ‘disk space low’). The software is still working as expected.

# ERROR: Due to a more serious problem, the software has not been able to perform some function.

# CRITICAL: A serious error, indicating that the program itself may be unable to continue running.

logging.basicConfig(filename='test.log',
                    level=logging.DEBUG,
                    filemode='w',
                    format='%(levelname)s:%(message)s')
##############################################################

class Screen:
    '''
    encapsulates printing and screen management
    in each frame, all objects are added to the screen according to updated positions, sizes and representations provided by them,
    and screen prints it all
    manages a static background array and a dynamic foreground array
    '''
    # https://stackoverflow.com/a/56335
    CURSOR_0 = "\033[0;0H"

    # https://stackoverflow.com/a/1348624
    CLEAR = "\033[2J"

    def __init__(self, height, width):
        logging.info("Inside SCREEN class's INIT()")
        self._height = height
        self._width = width
        part()
        logging.debug(f"Setting screens height as {height}")
        logging.debug(f"Setting screens width as {width}")
        logging.debug(f"conf . BGCOLOR IS  as {conf.BG_COLOR}")

        self._back_board = np.array(
            [
                [conf.BG_COLOR for j in range(self._width)]
             for i in range(self._height)],
            dtype='object')

        logging.debug(f"self.backboard SHAPE IS is  {self._back_board.shape}")
        logging.debug(f"self.backboard is  {self._back_board}")
        part()


            
        for i in range(self._height):
            for j in range(self._width):
                if random.random() < conf.ACCENT_AMT:  # random black dots
                    self._back_board[i][j] = conf.BG_ACCENT_COLOR

        # color the ground and the ceiling
        for i in range(self._height - conf.GND_HEIGHT, self._height):
            for j in range(self._width):
                self._back_board[i][j] = conf.GND_COLOR

        for i in range(conf.SKY_DEPTH):
            for j in range(self._width):
                self._back_board[i][j] = conf.SKY_COLOR

        self._fore_board = np.array([[' ' for j in range(self._width)]
                                     for i in range(self._height)],
                                    dtype='object')
        
        logging.debug(f"Finally is self.backboard is  \n{self._back_board}\n\n")
        logging.debug(f"Finally is self.foreboard (SHAPE: {self._fore_board.shape} is  \n{self._fore_board}\n\n")

    def clear(self):
        '''
        clears the foreground
        '''
        logging.info("Inside the clear() function of SCREEN CLASS\nWill set entire foreboard to empty")
        for i in range(self._height):
            for j in range(self._width):
                self._fore_board[i][j] = ' '

    def add(self, obj):
        '''
        add an object to the screen
        '''

        # object is not visible, prevent index out of bounds errors
        if True in obj.is_out():
            return

        pos, size, front = obj.show()

        x_start = pos[0]
        x_start_ = 0
        x_end = pos[0] + size[0]
        x_end_ = size[0]
        y_start = pos[1]
        y_start_ = 0
        y_end = pos[1] + size[1]
        y_end_ = size[1]

        # Now make sure if half the object is visible, it is rendered correctly

        if x_start < 0:
            x_start_ = 0 - x_start
            x_start = 0

        if y_start < 0:
            y_start_ = 0 - y_start
            y_start = 0

        if x_end > self._height:
            x_end_ = self._height - pos[0]
            x_end = self._height

        if y_end > self._width:
            y_end_ = self._width - pos[1]
            y_end = self._width

        try:
            self._fore_board[x_start:x_end, y_start:
                             y_end] = front[x_start_:x_end_, y_start_:y_end_]
        except (IndexError, ValueError
                ) as e:  # skip rendering for this frame in case of error
            return

    def print_board(self, frame_count):
        '''
        renders the screen
        '''
        part()
        logging.info("INSIDE THE print_board() function of screen.py")
        logging.info("Using the SETTING CURSON ON TOP ANSI SEQUENCE")
        print(self.CURSOR_0)
        for i in range(self._height):
            for j in range(self._width):  # frame count is used to move the black dots at the same rate as the game
                print(self._back_board[i][(j + frame_count) % self._width] +
                      self._fore_board[i][j],
                      end='')
            print('')
        part()

    def flash(self, color, frame_count, times=3):
        '''
        flashes the screen while halting and maintaining state to alert the user
        '''

        temp = np.array([[color for j in range(self._width)]
                         for i in range(self._height)],
                        dtype='object')
        for _ in range(times):
            print(self.CURSOR_0)
            for i in range(self._height):
                for j in range(self._width):
                    print(temp[i][j], end='')
                print('')
            time.sleep(0.1)
            self.print_board(frame_count)
            time.sleep(0.2)

    def game_over(self, won, game_score, game_time):
        '''
        print the game over screen
        '''

        print(Style.RESET_ALL + self.CLEAR + self.CURSOR_0 + '\n\n\n')

        if won:
            yoda = utils.get_art('yoda.txt')
            if yoda is not None:  # if file not available, skip
                print(Fore.YELLOW, end='')
                for i in range(yoda.shape[0]):
                    for j in range(yoda.shape[1]):
                        print(yoda[i][j], end='')
                    print('')
                time.sleep(2)
                print(Style.RESET_ALL + self.CLEAR + self.CURSOR_0 + '\n\n\n')

        go_text = utils.get_art('game-over.txt')
        if go_text is not None:  # if file not available, skip
            print(Fore.GREEN, end='')
            for i in range(go_text.shape[0]):
                for j in range(go_text.shape[1]):
                    print(go_text[i][j], end='')
                print('')

        print('\n\n', end='')

        if won:
            print(Style.BRIGHT + Fore.YELLOW + 'YOU WON :)')
        else:
            print(Style.BRIGHT + Fore.RED + 'YOU LOST :(')

        print(Fore.WHITE, end='')
        print('Score:', game_score)
        print('Time:', game_time)

        print(Style.DIM + '\nPress F to exit')
        print(Style.RESET_ALL)
